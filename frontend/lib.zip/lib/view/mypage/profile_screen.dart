import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  final bool isLoggedIn;

  const ProfileScreen({super.key, required this.isLoggedIn});

  @override
  Widget build(BuildContext context) {
    if (!isLoggedIn) {
      return Scaffold(
        appBar: AppBar(title: const Text('나의 정보')),
        body: const Center(
          child: Text('로그인해주세요'),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('나의 정보')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            ProfileItem(label: '이름', value: '김가천'),
            ProfileItem(label: '성별', value: '남자'),
            ProfileItem(label: '나이', value: '25세'),
            ProfileItem(label: '키', value: '175cm'),
            ProfileItem(label: '몸무게', value: '88kg'),
            ProfileItem(label: '알러지 정보', value: '우유, 땅콩'),
          ],
        ),
      ),
    );
  }
}

class ProfileItem extends StatelessWidget {
  final String label;
  final String value;

  const ProfileItem({super.key, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontSize: 16)),
          Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}